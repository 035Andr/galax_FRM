from galax_framework.main import Framework
from urls import routes, fronts
from wsgiref.simple_server import make_server

application = Framework(routes, fronts)

with make_server('', 8080, application) as httpd:
    print("Запуск на порту 8080...")
    httpd.serve_forever()



# Для запуска можно использовать gunicorn или uwsgi или их аналоги

# gunicorn - wsgi-коннектор
# pip install gunicorn
# gunicorn simple_wsgi:application

# uwsgi
# pip install uwsgi        # в первую очередь запускаем в терминале (установка)
# uwsgi --http :8080 --wsgi-file run.py    # 127.0.0.1:8080 потом это запускаем
